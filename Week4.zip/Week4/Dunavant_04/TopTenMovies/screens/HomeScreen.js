// HomeScreen.js
// Displays title and FlatList of movies

import React from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import MovieItem from '../components/MovieItem';

// Movie data stored inside variable
const topTenMovies = [
  {
    id: '1',
    title: 'Mission Impossible',
    rating: '8.0/10',
    image: require('../assets/images/missionimpossible.jpg'),
  },
  {
    id: '2',
    title: 'Top Gun',
    rating: '8.6/10',
    image: require('../assets/images/topgun.jpg'),
  },
  {
    id: '3',
    title: 'Forrest Gump',
    rating: '8.8/10',
    image: require('../assets/images/forrestgump.jpg'),
  },
  {
    id: '4',
    title: 'The Dark Knight',
    rating: '9.0/10',
    image: require('../assets/images/darkknight.jpg'),
  },
  {
    id: '5',
    title: 'The Matrix',
    rating: '8.7/10',
    image: require('../assets/images/matrix.jpg'),
  },
  {
    id: '6',
    title: 'Talladega Nights',
    rating: '6.6/10',
    image: require('../assets/images/talladega.jpg'),
  },
  {
    id: '7',
    title: 'Gladiator',
    rating: '8.5/10',
    image: require('../assets/images/gladiator.jpg'),
  },
  {
    id: '8',
    title: 'Inception',
    rating: '8.8/10',
    image: require('../assets/images/inception.jpg'),
  },
  {
    id: '9',
    title: 'Interstellar',
    rating: '8.6/10',
    image: require('../assets/images/interstellar.jpg'),
  },
  {
    id: '10',
    title: 'The Shawshank Redemption',
    rating: '9.3/10',
    image: require('../assets/images/shawshank.jpg'),
  },
];

export default function HomeScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>🎬Top Ten Movies</Text>

      <FlatList
        data={topTenMovies}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <MovieItem
            movieTitle={item.title}
            movieRating={item.rating}
            movieImage={item.image}
          />
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 15,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginBottom: 20,
  },
});

// MovieItem.js
// Custom component for displaying each movie

import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

export default function MovieItem({ movieTitle, movieRating, movieImage }) {
  return (
    <View style={styles.card}>
      <Image source={movieImage} style={styles.image} />
      <Text style={styles.title}>{movieTitle}</Text>
      <Text style={styles.rating}>⭐ Rating: {movieRating}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#222',
    padding: 15,
    marginBottom: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  image: {
    width: 150,
    height: 220,
    resizeMode: 'cover',
    borderRadius: 8,
    marginBottom: 10,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
  },
  rating: {
    fontSize: 16,
    color: '#FFD700',
    marginTop: 5,
  },
});
// Import React and components
import React from 'react';
import { View, Text, Button, FlatList, StyleSheet } from 'react-native';
import RecipeItem from '../components/RecipeItem';

// Displays list of recipes
export default function RecipesScreen({ recipes, goHome, goToAddRecipe, onDelete, onView }) {
  return (
    <View style={styles.container}>

      {/* Screen title */}
      <Text style={styles.title}>Your Recipes</Text>

      {/* FlatList renders RecipeItem components */}
      <FlatList
        data={recipes}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <RecipeItem
            recipe={item}
            onDelete={onDelete}
            onView={onView}
          />
        )}
      />

      {/* Navigation buttons */}
      <Button title="Add Recipe" onPress={goToAddRecipe} />
      <Button title="Home" onPress={goHome} />

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 15
  }
});
// Import React and useState
import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet } from 'react-native';

// Screen for adding a recipe
export default function AddRecipeScreen({ onSave, onCancel }) {

  // Store title input
  const [recipeTitle, setRecipeTitle] = useState('');

  // Store instructions input
  const [recipeText, setRecipeText] = useState('');

  return (
    <View style={styles.container}>

      {/* Title input field */}
      <TextInput
        placeholder="Recipe Title"
        style={styles.input}
        value={recipeTitle}
        onChangeText={setRecipeTitle}
      />

      {/* Instructions input field */}
      <TextInput
        placeholder="Recipe Instructions"
        style={styles.input}
        multiline
        value={recipeText}
        onChangeText={setRecipeText}
      />

      {/* Save button */}
      <Button
        title="Save"
        onPress={() => onSave(recipeTitle, recipeText)}
      />

      {/* Cancel button */}
      <Button
        title="Cancel"
        color="red"
        onPress={onCancel}
      />

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginVertical: 10,
    borderRadius: 6
  }
});
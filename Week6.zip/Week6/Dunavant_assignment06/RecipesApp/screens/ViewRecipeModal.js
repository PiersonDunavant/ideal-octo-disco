// Import React and modal components
import React from 'react';
import { Modal, View, Text, Button, StyleSheet } from 'react-native';

// Modal for viewing recipe details
export default function ViewRecipeModal({ visible, recipe, onClose }) {

  // If no recipe is selected, do not render modal
  if (!recipe) return null;

  return (
    <Modal visible={visible} animationType="slide">
      <View style={styles.container}>

        {/* Recipe title */}
        <Text style={styles.title}>{recipe.title}</Text>

        {/* Recipe instructions */}
        <Text style={styles.text}>{recipe.text}</Text>

        {/* Close modal button */}
        <Button title="Close" onPress={onClose} />

      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center'
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 15
  },
  text: {
    fontSize: 16,
    marginBottom: 20
  }
});
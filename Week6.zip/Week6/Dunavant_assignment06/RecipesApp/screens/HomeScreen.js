// Import React and UI components
import React from 'react';
import { View, Text, Button, Image, StyleSheet } from 'react-native';

// Home screen component
export default function HomeScreen({ goToRecipes }) {
  return (
    <View style={styles.container}>

      {/* App title */}
      <Text style={styles.title}>🍽 Recipes App</Text>

      {/* Stock image */}
      <Image
        source={{ uri: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061' }}
        style={styles.image}
      />

      {/* Button to navigate to Recipes */}
      <Button title="View Recipes" onPress={goToRecipes} />

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 20
  },
  image: {
    width: 300,
    height: 200,
    marginBottom: 20,
    borderRadius: 10
  }
});
// Import React and useState hook
import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';

// Import screen components
import HomeScreen from './screens/HomeScreen';
import RecipesScreen from './screens/RecipesScreen';
import AddRecipeScreen from './screens/AddRecipeScreen';
import ViewRecipeModal from './screens/ViewRecipeModal';

export default function App() {

  // Controls which screen is currently displayed
  const [currentScreen, setCurrentScreen] = useState('home');

  // Stores all recipe objects
  const [recipes, setRecipes] = useState([]);

  // Stores selected recipe for viewing
  const [selectedRecipe, setSelectedRecipe] = useState(null);

  // Controls modal visibility
  const [modalVisible, setModalVisible] = useState(false);

  // Adds a new recipe to state
  const addRecipeHandler = (title, text) => {
    const newRecipe = {
      id: Date.now().toString(),
      title: title,
      text: text
    };

    setRecipes(currentRecipes => [...currentRecipes, newRecipe]);
    setCurrentScreen('recipes');
  };

  // Deletes a recipe from state
  const deleteRecipeHandler = (id) => {
    setRecipes(currentRecipes =>
      currentRecipes.filter(recipe => recipe.id !== id)
    );
  };

  // Opens modal to view recipe
  const viewRecipeHandler = (recipe) => {
    setSelectedRecipe(recipe);
    setModalVisible(true);
  };

  // Closes modal
  const closeModalHandler = () => {
    setModalVisible(false);
  };

  return (
    <View style={styles.container}>

      {/* Show Home screen */}
      {currentScreen === 'home' && (
        <HomeScreen goToRecipes={() => setCurrentScreen('recipes')} />
      )}

      {/* Show Recipes screen */}
      {currentScreen === 'recipes' && (
        <RecipesScreen
          recipes={recipes}
          goHome={() => setCurrentScreen('home')}
          goToAddRecipe={() => setCurrentScreen('add')}
          onDelete={deleteRecipeHandler}
          onView={viewRecipeHandler}
        />
      )}

      {/* Show Add Recipe screen */}
      {currentScreen === 'add' && (
        <AddRecipeScreen
          onSave={addRecipeHandler}
          onCancel={() => setCurrentScreen('recipes')}
        />
      )}

      {/* Modal component */}
      <ViewRecipeModal
        visible={modalVisible}
        recipe={selectedRecipe}
        onClose={closeModalHandler}
      />

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  }
});
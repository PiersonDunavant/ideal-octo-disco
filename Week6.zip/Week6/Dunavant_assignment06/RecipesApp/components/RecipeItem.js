// Import React and UI components
import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

// Displays one recipe row
export default function RecipeItem({ recipe, onView, onDelete }) {
  return (
    <View style={styles.row}>

      {/* Display recipe title */}
      <Text style={styles.title}>{recipe.title}</Text>

      {/* View and Delete buttons */}
      <View style={styles.buttonRow}>
        <Button title="View" onPress={() => onView(recipe)} />
        <Button title="Delete" color="red" onPress={() => onDelete(recipe.id)} />
      </View>

    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    marginVertical: 8,
    backgroundColor: '#e3e3e3',
    borderRadius: 8
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold'
  },
  buttonRow: {
    flexDirection: 'row',
    gap: 10
  }
});
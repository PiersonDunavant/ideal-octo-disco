import React, {useState, useEffect} from "react";
import {NavigationContainer} from "@react-navigation/native";
import {createNativeStackNavigator} from "@react-navigation/native-stack";
import * as Font from "expo-font";

import HomeScreen from "./screens/HomeScreen";
import OrderReviewScreen from "./screens/OrderReviewScreen";

const Stack = createNativeStackNavigator();

export default function App(){

const [fontsLoaded,setFontsLoaded] = useState(false);

const [serviceTime,setServiceTime] = useState("standard");
const [serviceOptions,setServiceOptions] = useState([]);

const [newsletterSignup,setNewsletterSignup] = useState(false);
const [rentalMembership,setRentalMembership] = useState(false);

const [totalPrice,setTotalPrice] = useState(0);
const [subtotal,setSubtotal] = useState(0);
const [tax,setTax] = useState(0);

useEffect(()=>{
async function loadFonts(){

await Font.loadAsync({
customFont: require("./assets/fonts/CustomFont.ttf")
});

setFontsLoaded(true);

}

loadFonts();

},[]);

if(!fontsLoaded){
return null;
}

function calculateTotal(){

let total = 0;

if(serviceTime==="expedited") total+=50;
if(serviceTime==="nextday") total+=100;

serviceOptions.forEach(option=>{

if(option==="basic") total+=50;
if(option==="comprehensive") total+=75;
if(option==="flat") total+=20;
if(option==="brakes") total+=50;
if(option==="gears") total+=40;
if(option==="chain") total+=15;
if(option==="frame") total+=35;
if(option==="safety") total+=25;
if(option==="accessory") total+=10;

});

if(rentalMembership) total+=100;

let salesTax = total * .06;
let finalTotal = total + salesTax;

setSubtotal(total);
setTax(salesTax);
setTotalPrice(finalTotal);

}

function resetOrder(){

setServiceTime("standard");
setServiceOptions([]);
setNewsletterSignup(false);
setRentalMembership(false);
setSubtotal(0);
setTax(0);
setTotalPrice(0);

}

return(

<NavigationContainer>

<Stack.Navigator screenOptions={{headerShown:false}}>

<Stack.Screen name="Home">

{(props)=>(

<HomeScreen
{...props}

serviceTime={serviceTime}
setServiceTime={setServiceTime}

serviceOptions={serviceOptions}
setServiceOptions={setServiceOptions}

newsletterSignup={newsletterSignup}
setNewsletterSignup={setNewsletterSignup}

rentalMembership={rentalMembership}
setRentalMembership={setRentalMembership}

calculateTotal={calculateTotal}
/>

)}

</Stack.Screen>

<Stack.Screen name="OrderReview">

{(props)=>(

<OrderReviewScreen
{...props}

serviceTime={serviceTime}
serviceOptions={serviceOptions}

newsletterSignup={newsletterSignup}
rentalMembership={rentalMembership}

subtotal={subtotal}
tax={tax}
totalPrice={totalPrice}

resetOrder={resetOrder}
/>

)}

</Stack.Screen>

</Stack.Navigator>

</NavigationContainer>

);

}

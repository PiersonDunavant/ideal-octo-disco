import React from "react";
import {Button, StyleSheet} from "react-native";

export default function NavButton(props){

return(

<Button
title={props.title}
onPress={props.onPress}
/>

)

}
import React from "react";
import {Text, StyleSheet} from "react-native";

export default function Title(props){

return(

<Text style={styles.title}>
{props.text}
</Text>

)

}

const styles = StyleSheet.create({

title:{
fontSize:30,
textAlign:"center",
marginBottom:20
}

});
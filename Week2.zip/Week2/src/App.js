import React from 'react';
import ProfileCard from './components/ProfileCard';
import '../styles/App.css';

function App() {
  return <ProfileCard />;
}

export default App;
